/**
 * VOZ EM AÇÃO — Backend em Google Apps Script (v8)
 * ---------------------------------------------------
 * Serve o livro digital (GitHub Pages) e grava/lê a planilha "progresso_voz_em_acao".
 *
 * Novidades da v8: dois testes diferentes no mesmo script — mídias sociais (12 afirmações, 6 temas, PDF de 3 páginas) e clientes (48 afirmações, 12 temas, PDF de 15 páginas); o script confere o nº de respostas de cada link. Novo texto do e-mail da devolutiva (sem cabeçalho/rodapé). Novidades da v6 (sobre a v5): ação submitTeste, dos links "só o teste" (mídias sociais e clientes):
 *  - recebe as respostas e os PDFs da devolutiva (gerados no navegador), confere o código de acesso;
 *  - salva o PDF COMPLETO (15 páginas) na pasta do Drive: Devolutiva_Midias_Sociais ou Devolutiva_Clientes
 *    (criadas sozinhas, no Drive da conta que publicou o script, se ainda não existirem);
 *  - envia por e-mail: mídias sociais = PDF simples (3 páginas); clientes = PDF completo (15 páginas);
 *  - registra na aba "Registro_Devolutivas": quem respondeu, quando, de qual link e o status ("Enviado").
 *
 * Novidades da v5 (sobre a v4):
 *  - Duas colunas novas, criadas sozinhas se ainda não existirem: Empresa (já existia, agora é
 *    preenchida pela pessoa) e WhatsApp.
 *  - Toda vez que a pessoa se identifica, Nome/Departamento/Empresa/WhatsApp são atualizados na
 *    linha dela (não só na primeira vez).
 *  - Gera sozinho uma segunda aba, "Respostas_Teste": uma linha por pessoa com as 48 respostas do
 *    Teste de Comunicação já abertas em colunas (Q1..Q48) e os 12 níveis calculados — pronta para
 *    tabela dinâmica/indicadores, sem precisar abrir o JSON.
 *
 * Ações: requestCode, verifyCode, identify, set, saveAnswers, submitTeste, ping.
 * Para desligar o código de acesso por e-mail, mude REQUIRE_AUTH para false.
 */

const SHEET_NAME = 'Progresso';
const TEST_SHEET_NAME = 'Respostas_Teste';
const REG_SHEET_NAME = 'Registro_Devolutivas';
const MODOS = {
  midias:   { origem: 'Link mídias sociais',        pasta: 'Devolutiva_Midias_Sociais', enviada: 'Resumo (3 páginas)',   nq: 12 },
  clientes: { origem: 'Link Cliente Voz em Ação',   pasta: 'Devolutiva_Clientes',       enviada: 'Completa (15 páginas)', nq: 48 }
};
const CAP_INTRO_NAME = 'Introdução';   // capítulo onde ficam as respostas do Teste de Comunicação
const REQUIRE_AUTH = true;   // true = exige código por e-mail
const TOKEN_DAYS = 30;       // por quantos dias a pessoa continua "logada" no aparelho
const CODE_MINUTES = 10;     // validade do código
const REQUIRED = ['Nome', 'Email', 'Departamento', 'Empresa', 'Gestor_Email', 'Capitulo',
  'Semana1', 'Semana1_Data', 'Semana2', 'Semana2_Data', 'Semana3', 'Semana3_Data',
  'Semana4', 'Semana4_Data', 'Semana5', 'Semana5_Data'];
const AUTO_ADD_COLS = ['WhatsApp', 'Respostas_JSON'];   // colunas novas que o script cria sozinho se faltarem

const CATS = ['Autoconhecimento', 'Presença', 'Empatia', 'Escuta', 'Linguagem', 'CNV', 'Assertividade',
  'Autenticidade', 'Conversas difíceis', 'Storytelling', 'Feedback', 'Confiança'];
const BLOCK_CAT = [0, 1, 2, 3, 7, 9, 6, 4, 8, 5, 10, 11];

/** Rode UMA vez no editor (escolha "autorizar" na lista e clique em Executar) para liberar o envio de e-mails. */
function autorizar() {
  Logger.log('E-mails que ainda podem ser enviados hoje: ' + MailApp.getRemainingDailyQuota());
  Logger.log('Drive liberado: ' + DriveApp.getRootFolder().getName());
}

function doGet(e) { return handle(e); }
function doPost(e) { return handle(e); }

function handle(e) {
  const p = (e && e.parameter) || {};
  try {
    if (p.action === 'ping') return respond({ ok: true, message: 'Voz em Ação — backend no ar (v8)', auth: REQUIRE_AUTH });
    if (p.action === 'requestCode') return respond(requestCode(p));
    if (p.action === 'verifyCode') return respond(verifyCode(p));
    if (p.action === 'submitTeste') return respond(submitTeste(p));

    if (['identify', 'set', 'saveAnswers'].indexOf(p.action) === -1) return respond({ ok: false, error: 'Ação inválida.' });
    if (REQUIRE_AUTH && !checkToken(p.token, p.email)) return respond({ ok: false, error: 'auth' });

    const lock = LockService.getScriptLock();
    try { lock.waitLock(20000); }
    catch (err) { return respond({ ok: false, error: 'Servidor ocupado, tente novamente.' }); }
    try {
      const sheet = getSheet();
      const t = getTable(sheet);
      if (t.error) return respond({ ok: false, error: t.error });
      if (p.action === 'identify') return respond(handleIdentify(sheet, t, p));
      if (p.action === 'set') return respond(handleSet(sheet, t, p));
      return respond(handleSaveAnswers(sheet, t, p));
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return respond({ ok: false, error: String(err) });
  }
}

/* ---------- ACESSO POR CÓDIGO ---------- */

function norm(email) { return String(email || '').trim().toLowerCase(); }

function secret() {
  const props = PropertiesService.getScriptProperties();
  let s = props.getProperty('SECRET');
  if (!s) { s = Utilities.getUuid() + Utilities.getUuid(); props.setProperty('SECRET', s); }
  return s;
}
function sign(text) {
  return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(text, secret()));
}
function makeToken(email) {
  const body = norm(email) + '|' + (Date.now() + TOKEN_DAYS * 86400000);
  return Utilities.base64EncodeWebSafe(body) + '.' + sign(body);
}
function checkToken(token, email) {
  if (!token || !email) return false;
  const parts = String(token).split('.');
  if (parts.length !== 2) return false;
  let body;
  try { body = Utilities.newBlob(Utilities.base64DecodeWebSafe(parts[0])).getDataAsString(); }
  catch (err) { return false; }
  if (sign(body) !== parts[1]) return false;
  const i = body.lastIndexOf('|');
  return body.slice(0, i) === norm(email) && Number(body.slice(i + 1)) > Date.now();
}

function requestCode(p) {
  if (!REQUIRE_AUTH) return { ok: true, skip: true };
  const email = norm(p.email);
  if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, error: 'E-mail inválido.' };

  const cache = CacheService.getScriptCache();
  const asked = Number(cache.get('rq:' + email) || 0);
  if (asked >= 5) return { ok: false, error: 'Muitos pedidos de código. Aguarde alguns minutos e tente de novo.' };
  cache.put('rq:' + email, String(asked + 1), 900);

  const code = ('000000' + (parseInt(Utilities.getUuid().replace(/-/g, '').slice(0, 8), 16) % 1000000)).slice(-6);
  cache.put('cd:' + email, sign('code|' + email + '|' + code), CODE_MINUTES * 60);
  cache.put('at:' + email, '0', CODE_MINUTES * 60);

  try {
    MailApp.sendEmail({
      to: email,
      name: 'Voz em Ação',
      subject: 'Seu código de acesso: ' + code,
      htmlBody: '<div style="font-family:Arial,sans-serif;max-width:420px">' +
        '<h2 style="color:#5c3e94;margin:0 0 8px">Voz em Ação</h2>' +
        '<p>Use este código para entrar no seu planner digital:</p>' +
        '<p style="font-size:34px;letter-spacing:8px;font-weight:bold;margin:12px 0">' + code + '</p>' +
        '<p style="color:#666">O código vale por ' + CODE_MINUTES + ' minutos. Se não foi você quem pediu, ignore este e-mail.</p></div>'
    });
  } catch (err) {
    return { ok: false, error: 'Não foi possível enviar o e-mail agora. Tente novamente em instantes.' };
  }
  return { ok: true };
}

function verifyCode(p) {
  if (!REQUIRE_AUTH) return { ok: true, token: '' };
  const email = norm(p.email);
  const cache = CacheService.getScriptCache();
  const stored = cache.get('cd:' + email);
  if (!stored) return { ok: false, error: 'Código expirado. Peça um novo código.' };
  const tries = Number(cache.get('at:' + email) || 0);
  if (tries >= 5) { cache.remove('cd:' + email); return { ok: false, error: 'Muitas tentativas. Peça um novo código.' }; }
  if (sign('code|' + email + '|' + String(p.code || '').replace(/\s/g, '')) !== stored) {
    cache.put('at:' + email, String(tries + 1), CODE_MINUTES * 60);
    return { ok: false, error: 'Código incorreto.' };
  }
  cache.remove('cd:' + email);
  return { ok: true, token: makeToken(email) };
}

/* ---------- PLANILHA PRINCIPAL ---------- */

function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_NAME) || ss.getSheets()[0];
}

/** Lê a tabela: acha a linha de cabeçalho, garante as colunas novas (WhatsApp, Respostas_JSON) e devolve tudo já mapeado. */
function getTable(sheet) {
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, REQUIRED.length + AUTO_ADD_COLS.length).setValues([REQUIRED.concat(AUTO_ADD_COLS)]);
  }
  let values = sheet.getDataRange().getValues();
  let h = -1;
  for (let i = 0; i < Math.min(values.length, 10); i++) {
    const row = values[i].map(c => String(c).trim());
    if (row.indexOf('Email') > -1 && row.indexOf('Capitulo') > -1) { h = i; break; }
  }
  if (h === -1) return { error: 'Cabeçalho não encontrado. A planilha precisa ter as colunas Email e Capitulo.' };

  let headers = values[h].map(c => String(c).trim());
  const missing = REQUIRED.filter(c => headers.indexOf(c) === -1);
  if (missing.length) return { error: 'Faltam colunas na planilha: ' + missing.join(', ') };

  let changed = false;
  AUTO_ADD_COLS.forEach(col => {
    if (headers.indexOf(col) === -1) { sheet.getRange(h + 1, headers.length + 1).setValue(col); headers.push(col); changed = true; }
  });
  if (changed) values = sheet.getDataRange().getValues();
  return { headers: headers, values: values, headerRow: h };
}

function findRow(t, email, capitulo) {
  const iE = t.headers.indexOf('Email'), iC = t.headers.indexOf('Capitulo');
  const em = norm(email), cp = String(capitulo).trim();
  for (let i = t.headerRow + 1; i < t.values.length; i++) {
    if (norm(t.values[i][iE]) === em && String(t.values[i][iC]).trim() === cp) {
      return { rowIndex: i + 1, row: t.values[i] };
    }
  }
  return null;
}

function handleIdentify(sheet, t, p) {
  if (!p.email || !p.capitulo) return { ok: false, error: 'E-mail ou capítulo ausente.' };

  const fields = {
    Nome: p.nome || '', Email: String(p.email).trim(), Departamento: p.departamento || '',
    Empresa: p.empresa || '', WhatsApp: p.whatsapp || '', Gestor_Email: p.gestorEmail || '', Capitulo: p.capitulo
  };
  let found = findRow(t, p.email, p.capitulo);
  if (!found) {
    const newRow = t.headers.map(h => (h in fields) ? fields[h] : '');
    sheet.appendRow(newRow);
    found = { rowIndex: sheet.getLastRow(), row: newRow };
  } else {
    // atualiza os dados de identificação a cada vez (departamento/empresa/whatsapp podem ter sido completados agora)
    ['Nome', 'Departamento', 'Empresa', 'WhatsApp'].forEach(h => {
      const i = t.headers.indexOf(h);
      if (i > -1 && fields[h]) { sheet.getRange(found.rowIndex, i + 1).setValue(fields[h]); found.row[i] = fields[h]; }
    });
  }
  const obj = {};
  t.headers.forEach((h, i) => { obj[h] = found.row[i]; });
  return { ok: true, data: obj };
}

function handleSet(sheet, t, p) {
  if (!p.email || !p.capitulo || !p.semana) return { ok: false, error: 'Parâmetros ausentes.' };
  const found = findRow(t, p.email, p.capitulo);
  if (!found) return { ok: false, error: 'Registro não encontrado — recarregue a página.' };

  const valor = p.valor === 'true';
  const cS = t.headers.indexOf('Semana' + p.semana);
  const cD = t.headers.indexOf('Semana' + p.semana + '_Data');
  if (cS === -1 || cD === -1) return { ok: false, error: 'Semana inválida.' };

  sheet.getRange(found.rowIndex, cS + 1).setValue(valor);
  sheet.getRange(found.rowIndex, cD + 1).setValue(valor ? new Date() : '');
  return { ok: true };
}

function handleSaveAnswers(sheet, t, p) {
  if (!p.email || !p.capitulo) return { ok: false, error: 'Parâmetros ausentes.' };
  const found = findRow(t, p.email, p.capitulo);
  if (!found) return { ok: false, error: 'Registro não encontrado.' };

  const col = t.headers.indexOf('Respostas_JSON');
  sheet.getRange(found.rowIndex, col + 1).setValue(p.data || '{}');

  if (p.capitulo === CAP_INTRO_NAME) {
    const g = name => { const i = t.headers.indexOf(name); return i === -1 ? '' : found.row[i]; };
    try {
      syncTestResults({ email: p.email, nome: g('Nome'), departamento: g('Departamento'), empresa: g('Empresa'), whatsapp: g('WhatsApp') }, p.data);
    } catch (err) { /* a aba de indicadores é um extra: se falhar, não impede o salvamento normal */ }
  }
  return { ok: true };
}

/* ---------- ABA "Respostas_Teste" (indicadores) ---------- */

/** Upsert de uma linha por pessoa, com as 48 respostas já em colunas e os 12 níveis calculados. */
function syncTestResults(person, dataJson) {
  let data;
  try { data = JSON.parse(dataJson || '{}'); } catch (err) { return; }
  if (!data.t_1) return;   // ainda não começou o teste — nada a sincronizar

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let rs = ss.getSheetByName(TEST_SHEET_NAME);
  const header = ['Nome', 'Email', 'Departamento', 'Empresa', 'WhatsApp', 'Atualizado_em'];
  for (let i = 1; i <= 48; i++) header.push('Q' + i);
  CATS.forEach(c => header.push(c));

  if (!rs) { rs = ss.insertSheet(TEST_SHEET_NAME); rs.getRange(1, 1, 1, header.length).setValues([header]); }
  else if (rs.getLastRow() === 0) rs.getRange(1, 1, 1, header.length).setValues([header]);

  const vals = rs.getDataRange().getValues();
  const hdrs = vals[0];
  const emailCol = hdrs.indexOf('Email');
  let rowIdx = -1;
  for (let i = 1; i < vals.length; i++) { if (norm(vals[i][emailCol]) === norm(person.email)) { rowIdx = i + 1; break; } }

  const levels = CATS.map((_, ci) => {
    const b = BLOCK_CAT.indexOf(ci);
    const v = [0, 1, 2, 3].map(j => Number(data['t_' + (b * 4 + j + 1)]) || 0);
    return v.every(x => x) ? Math.round(v.reduce((a, x) => a + x, 0) / 4 * 2) : '';
  });
  const row = [person.nome || '', person.email || '', person.departamento || '', person.empresa || '', person.whatsapp || '', new Date()];
  for (let i = 1; i <= 48; i++) row.push(data['t_' + i] || '');
  levels.forEach(l => row.push(l));

  if (rowIdx === -1) rs.appendRow(row); else rs.getRange(rowIdx, 1, 1, row.length).setValues([row]);
}


/* ---------- LINKS "SÓ O TESTE": DEVOLUTIVA POR E-MAIL ---------- */

function pastaDrive(nome) {
  const it = DriveApp.getFoldersByName(nome);
  return it.hasNext() ? it.next() : DriveApp.createFolder(nome);
}

function nomeArquivo(nome) {
  return String(nome || 'Participante').replace(/[^\wÀ-ÿ ]+/g, '').trim().replace(/\s+/g, '_').slice(0, 40) || 'Participante';
}

function pdfBlob(b64, nome) {
  const bytes = Utilities.base64Decode(b64 || '');
  if (!bytes.length || String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== '%PDF') throw new Error('PDF inválido.');
  return Utilities.newBlob(bytes, 'application/pdf', nome);
}

function submitTeste(p) {
  const modo = MODOS[p.modo];
  if (!modo) return { ok: false, error: 'Link de teste inválido.' };
  const email = norm(p.email);
  if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, error: 'E-mail inválido.' };
  if (REQUIRE_AUTH && !checkToken(p.token, email)) return { ok: false, error: 'auth' };
  if (!p.completo) return { ok: false, error: 'PDF da devolutiva ausente.' };
  if (p.modo === 'midias' && !p.simples) return { ok: false, error: 'PDF simples ausente.' };
  // confere se vieram todas as respostas do teste deste link (12 nas mídias, 48 nos clientes)
  let respostas = {};
  try { respostas = JSON.parse(p.respostas || '{}'); } catch (err) {}
  for (let i = 1; i <= modo.nq; i++) if (!respostas['t_' + i]) return { ok: false, error: 'Responda todas as ' + modo.nq + ' afirmações do teste.' };

  const cache = CacheService.getScriptCache();
  const n = Number(cache.get('sb:' + email) || 0);
  if (n >= 5) return { ok: false, error: 'Muitos envios para este e-mail. Tente de novo mais tarde.' };
  cache.put('sb:' + email, String(n + 1), 3600);

  const lock = LockService.getScriptLock();
  try { lock.waitLock(25000); } catch (err) { return { ok: false, error: 'Servidor ocupado, tente novamente.' }; }
  let linkDrive = '', status = 'Enviado', erro = '';
  try {
    const base = 'Devolutiva_VozEmAcao_' + nomeArquivo(p.nome);
    const stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd_HHmm');
    // 1) PDF completo sempre vai para a pasta do link
    try {
      const f = pastaDrive(modo.pasta).createFile(pdfBlob(p.completo, base + '_' + stamp + (p.modo === 'midias' ? '_resumo.pdf' : '_completa.pdf')));
      linkDrive = f.getUrl();
    } catch (err) { status = 'Erro ao salvar no Drive'; erro = String(err); }
    // 2) e-mail: simples (mídias) ou completo (clientes)
    try {
      if (MailApp.getRemainingDailyQuota() < 1) throw new Error('limite diário de e-mails atingido');
      const anexo = p.modo === 'midias' ? pdfBlob(p.simples, base + '_resumo.pdf') : pdfBlob(p.completo, base + '_completa.pdf');
      const primeiro = String(p.nome || '').trim().split(/\s+/)[0] || '';
      MailApp.sendEmail({
        to: email, name: 'Voz em Ação',
        subject: 'Sua devolutiva do Teste da Comunicação — Voz em Ação',
        htmlBody: '<div style="font-family:Arial,sans-serif;max-width:480px;color:#222;line-height:1.5">' +
          '<p>Olá' + (primeiro ? ', ' + primeiro.replace(/[<>&"]/g, '') : '') + '!</p>' +
          '<p>Obrigada por fazer o Teste da Comunicação Voz em Ação. Leia sua devolutiva que está em anexo (PDF).</p>' +
          '<p>Sua voz ganha força quando consciência e ação caminham juntas.</p>' +
          '<p><b>Coloque sua Voz em Ação!!!</b></p>' +
          '<p>Boa leitura!</p></div>',
        attachments: [anexo]
      });
    } catch (err) { status = 'Erro no e-mail'; erro = String(err); }
    registrarDevolutiva(p, email, modo, status, erro, linkDrive);
  } finally {
    lock.releaseLock();
  }
  if (status !== 'Enviado') return { ok: false, error: erro || status };
  return { ok: true };
}

/** Uma linha por devolutiva: quem, quando, de qual link, o que foi enviado e o status. */
function registrarDevolutiva(p, email, modo, status, erro, linkDrive) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let rs = ss.getSheetByName(REG_SHEET_NAME);
  const header = ['Data_Hora', 'Nome', 'Email', 'Link_Origem', 'Devolutiva_Enviada', 'Status', 'Observacao', 'Empresa', 'WhatsApp', 'Departamento',
    'Pct_Forcas', 'Pct_Investir', 'Pct_Prioridade', 'PDF_Completo_Drive'];
  for (let i = 1; i <= 48; i++) header.push('Q' + i);
  if (!rs) rs = ss.insertSheet(REG_SHEET_NAME);
  if (rs.getLastRow() === 0) { rs.getRange(1, 1, 1, header.length).setValues([header]); rs.setFrozenRows(1); }
  let pct = {}, ans = {};
  try { pct = JSON.parse(p.pct || '{}'); } catch (err) {}
  try { ans = JSON.parse(p.respostas || '{}'); } catch (err) {}
  const row = [new Date(), p.nome || '', email, modo.origem, modo.enviada, status, erro || '', p.empresa || '', p.whatsapp || '', p.departamento || '',
    pct.forca != null ? pct.forca : '', pct.investir != null ? pct.investir : '', pct.prioridade != null ? pct.prioridade : '', linkDrive];
  for (let i = 1; i <= 48; i++) row.push(ans['t_' + i] || '');
  rs.appendRow(row);
}

function respond(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
